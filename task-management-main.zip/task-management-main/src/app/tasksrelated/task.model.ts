export interface Task {
  id: string;
  name: string;
  content: string;
  status: string;
  startdate: Date;
  enddate: Date;
}
